%-----------------------------------------------------------------------
% Job saved on 23-Apr-2021 16:25:26 by cfg_util (rev $Rev: 7345 $)
% spm SPM - SPM12 (7487)
% cfg_basicio BasicIO - Unknown
%-----------------------------------------------------------------------
matlabbatch{1}.cfg_basicio.var_ops.cfg_named_input.name = 'subject_folder';
matlabbatch{1}.cfg_basicio.var_ops.cfg_named_input.input = '<UNDEFINED>';
matlabbatch{2}.cfg_basicio.run_ops.runjobs.jobs = {'C:\Users\ohund\Documents\MATLAB\solo\level_0_2_1_realignment_estimate.m'};
matlabbatch{2}.cfg_basicio.run_ops.runjobs.inputs{1}{1}.instr =  cfg_dep('Named Input: root', substruct('.','val', '{}',{1}, '.','val', '{}',{1}, '.','val', '{}',{1}), substruct('.','input'));
matlabbatch{2}.cfg_basicio.run_ops.runjobs.inputs{1}{2}.instr = 'sub01';
matlabbatch{2}.cfg_basicio.run_ops.runjobs.inputs{2}{1}.instr = cfg_dep('Named Input: root', substruct('.','val', '{}',{1}, '.','val', '{}',{1}, '.','val', '{}',{1}), substruct('.','input'));
matlabbatch{2}.cfg_basicio.run_ops.runjobs.inputs{2}{2}.instr = 'sub02';
matlabbatch{2}.cfg_basicio.run_ops.runjobs.inputs{3}{1}.instr = cfg_dep('Named Input: root', substruct('.','val', '{}',{1}, '.','val', '{}',{1}, '.','val', '{}',{1}), substruct('.','input'));
matlabbatch{2}.cfg_basicio.run_ops.runjobs.inputs{3}{2}.instr = 'sub03';
matlabbatch{2}.cfg_basicio.run_ops.runjobs.inputs{4}{1}.instr = cfg_dep('Named Input: root', substruct('.','val', '{}',{1}, '.','val', '{}',{1}, '.','val', '{}',{1}), substruct('.','input'));
matlabbatch{2}.cfg_basicio.run_ops.runjobs.inputs{4}{2}.instr = 'sub04';
matlabbatch{2}.cfg_basicio.run_ops.runjobs.inputs{5}{1}.instr = cfg_dep('Named Input: root', substruct('.','val', '{}',{1}, '.','val', '{}',{1}, '.','val', '{}',{1}), substruct('.','input'));
matlabbatch{2}.cfg_basicio.run_ops.runjobs.inputs{5}{2}.instr = 'sub05';
matlabbatch{2}.cfg_basicio.run_ops.runjobs.inputs{6}{1}.instr = cfg_dep('Named Input: root', substruct('.','val', '{}',{1}, '.','val', '{}',{1}, '.','val', '{}',{1}), substruct('.','input'));
matlabbatch{2}.cfg_basicio.run_ops.runjobs.inputs{6}{2}.instr = 'sub06';
matlabbatch{2}.cfg_basicio.run_ops.runjobs.inputs{7}{1}.instr = cfg_dep('Named Input: root', substruct('.','val', '{}',{1}, '.','val', '{}',{1}, '.','val', '{}',{1}), substruct('.','input'));
matlabbatch{2}.cfg_basicio.run_ops.runjobs.inputs{7}{2}.instr = 'sub49';
matlabbatch{2}.cfg_basicio.run_ops.runjobs.inputs{8}{1}.instr = cfg_dep('Named Input: root', substruct('.','val', '{}',{1}, '.','val', '{}',{1}, '.','val', '{}',{1}), substruct('.','input'));
matlabbatch{2}.cfg_basicio.run_ops.runjobs.inputs{8}{2}.instr = 'sub50';
matlabbatch{2}.cfg_basicio.run_ops.runjobs.inputs{9}{1}.instr = cfg_dep('Named Input: root', substruct('.','val', '{}',{1}, '.','val', '{}',{1}, '.','val', '{}',{1}), substruct('.','input'));
matlabbatch{2}.cfg_basicio.run_ops.runjobs.inputs{9}{2}.instr = 'sub51';
matlabbatch{2}.cfg_basicio.run_ops.runjobs.inputs{10}{1}.instr = cfg_dep('Named Input: root', substruct('.','val', '{}',{1}, '.','val', '{}',{1}, '.','val', '{}',{1}), substruct('.','input'));
matlabbatch{2}.cfg_basicio.run_ops.runjobs.inputs{10}{2}.instr = 'sub52';
matlabbatch{2}.cfg_basicio.run_ops.runjobs.inputs{11}{1}.instr = cfg_dep('Named Input: root', substruct('.','val', '{}',{1}, '.','val', '{}',{1}, '.','val', '{}',{1}), substruct('.','input'));
matlabbatch{2}.cfg_basicio.run_ops.runjobs.inputs{11}{2}.instr = 'sub53';
matlabbatch{2}.cfg_basicio.run_ops.runjobs.inputs{12}{1}.instr = cfg_dep('Named Input: root', substruct('.','val', '{}',{1}, '.','val', '{}',{1}, '.','val', '{}',{1}), substruct('.','input'));
matlabbatch{2}.cfg_basicio.run_ops.runjobs.inputs{12}{2}.instr = 'sub54';
matlabbatch{2}.cfg_basicio.run_ops.runjobs.inputs{13}{1}.instr = cfg_dep('Named Input: root', substruct('.','val', '{}',{1}, '.','val', '{}',{1}, '.','val', '{}',{1}), substruct('.','input'));
matlabbatch{2}.cfg_basicio.run_ops.runjobs.inputs{13}{2}.instr = 'sub55';
matlabbatch{2}.cfg_basicio.run_ops.runjobs.inputs{14}{1}.instr = cfg_dep('Named Input: root', substruct('.','val', '{}',{1}, '.','val', '{}',{1}, '.','val', '{}',{1}), substruct('.','input'));
matlabbatch{2}.cfg_basicio.run_ops.runjobs.inputs{14}{2}.instr = 'sub56';
matlabbatch{2}.cfg_basicio.run_ops.runjobs.inputs{15}{1}.instr = cfg_dep('Named Input: root', substruct('.','val', '{}',{1}, '.','val', '{}',{1}, '.','val', '{}',{1}), substruct('.','input'));
matlabbatch{2}.cfg_basicio.run_ops.runjobs.inputs{15}{2}.instr = 'sub57';
matlabbatch{2}.cfg_basicio.run_ops.runjobs.inputs{16}{1}.instr = cfg_dep('Named Input: root', substruct('.','val', '{}',{1}, '.','val', '{}',{1}, '.','val', '{}',{1}), substruct('.','input'));
matlabbatch{2}.cfg_basicio.run_ops.runjobs.inputs{16}{2}.instr = 'sub58';
matlabbatch{2}.cfg_basicio.run_ops.runjobs.inputs{17}{1}.instr = cfg_dep('Named Input: root', substruct('.','val', '{}',{1}, '.','val', '{}',{1}, '.','val', '{}',{1}), substruct('.','input'));
matlabbatch{2}.cfg_basicio.run_ops.runjobs.inputs{17}{2}.instr = 'sub59';
matlabbatch{2}.cfg_basicio.run_ops.runjobs.inputs{18}{1}.instr = cfg_dep('Named Input: root', substruct('.','val', '{}',{1}, '.','val', '{}',{1}, '.','val', '{}',{1}), substruct('.','input'));
matlabbatch{2}.cfg_basicio.run_ops.runjobs.inputs{18}{2}.instr = 'sub60';
matlabbatch{2}.cfg_basicio.run_ops.runjobs.save.savejobs.outstub = 'solo';
matlabbatch{2}.cfg_basicio.run_ops.runjobs.save.savejobs.outdir = {'C:\Users\ohund\Documents\MATLAB\batches'};
matlabbatch{2}.cfg_basicio.run_ops.runjobs.missing = 'error';